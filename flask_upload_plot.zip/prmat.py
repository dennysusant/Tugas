from flask import Flask, abort, jsonify, render_template,url_for, request,send_from_directory,redirect
import plotly
import plotly.graph_objects as go 
import chart_studio.plotly as py 
import numpy as np 
import pandas as pd 
import json
import os
from werkzeug.utils import secure_filename
import csv
import matplotlib.pyplot as plt
import matplotlib.image as im
from mpl_toolkits.mplot3d import axes3d


app=Flask(__name__)


@app.route('/file/<path:path>')
def aksesFile(path):
    return send_from_directory ('file',path)

app.config['UPLOAD_FOLDER']='./file'
@app.route('/')
def home():
    return render_template('upload.html')

@app.route('/upload', methods=['GET','POST'])
def upload():
    if request.method=='POST':
        myfile = pd.read_csv(request.files['file'])
        filex = np.random.rand(1)
        x=(list(myfile['x']))
        y=(list(myfile['y']))
        plt.plot(x,y)
        plt.savefig('./file/{}.png'.format(filex))
        return render_template('baca.html',x='{}.png'.format(filex))


    
if __name__=='__main__':
    app.run(debug=True)