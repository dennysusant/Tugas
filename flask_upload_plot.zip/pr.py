from flask import Flask, abort, jsonify, render_template,url_for, request,send_from_directory,redirect
import plotly
import plotly.graph_objects as go 
import chart_studio.plotly as py 
import numpy as np 
import pandas as pd 
import json
import os
from werkzeug.utils import secure_filename
import csv


app=Flask(__name__)
app.config['UPLOAD_FOLDER']='./file'
@app.route('/')
def home():
    return render_template('upload.html')

@app.route('/upload', methods=['GET','POST'])
def upload():
    if request.method=='POST':
        myfile = pd.read_csv(request.files['file'])
        x=(list(myfile['x']))
        y=(list(myfile['y']))
        fig=go.Scatter(x=x,y=y)
        figjson=json.dumps([fig],cls=plotly.utils.PlotlyJSONEncoder)
        return render_template('home.html',x=figjson)

# @app.route('/file/<path:path>')
# def aksesFile(path):
#     data=pd.read_csv('file',path)
#     df=pd.DataFrame(data)
#     return df





    
if __name__=='__main__':
    app.run(debug=True)